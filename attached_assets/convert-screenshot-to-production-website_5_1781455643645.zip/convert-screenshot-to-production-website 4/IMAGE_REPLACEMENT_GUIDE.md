# 📸 Image Replacement Guide — The Harmony Palms

## Quick Start
Just replace files in `public/images/` with your own images (keep the same filenames) and the site will automatically use them. No code changes needed!

---

## 🪷 Logo

**File:** `public/logo.svg` (or `public/logo.png`)

**Recommended:**
- Transparent PNG or SVG (works in both dark & light themes)
- If your logo has a dark background, it looks perfect in dark mode
- For best results, export at 512×512px or larger

**To replace:**
1. Save your logo as `logo.svg` or `logo.png` in the `public/` folder
2. The site auto-loads it in the header, footer, and browser tab

---

## 🏠 Hero Section

**File:** `public/images/hero-massage.jpg`

**Recommended:**
- Resolution: **1920×1280px** or larger
- Format: JPG (best balance of quality vs. file size)
- Mood: warm, dark, luxury spa scene
- Aspect ratio: 3:2 landscape

**Tip:** Keep file size under 500KB for fast load. Use [TinyJPG.com](https://tinyjpg.com) to compress.

---

## 📂 Service Category Banners

All service categories use the same aspect ratio for a consistent look:

| File | Category | Aspect Ratio |
|------|----------|--------------|
| `ritual.jpg` | Signature Rituals | 4:5 portrait |
| `massage.jpg` | Therapeutic Massages | 4:5 portrait |
| `couples.jpg` | Couples Experiences | 4:5 portrait |
| `beauty.jpg` | Beauty Care | 4:5 portrait |
| `addons.jpg` | Add-Ons & Experiences | 4:5 portrait |
| `homeservice.jpg` | Home Services | 4:5 portrait |

**Recommended:**
- Resolution: **800×1000px** (or larger — 1200×1500px for retina)
- Format: JPG
- Compress to under 200KB each
- Dark, moody, spa-like imagery works best

---

## 🌟 Experience Cards

| File | Used In | Aspect Ratio |
|------|---------|--------------|
| `retreat.jpg` | The Harmony Retreat card | 4:5 portrait |
| `couples.jpg` | Couples Retreat card | 4:5 portrait (shared) |
| `ritual.jpg` | Royal Palms Ritual card | 4:5 portrait (shared) |

**Tip:** You can use the same image for multiple cards if it fits the mood.

---

## 🏛️ About Section

**File:** `public/images/interior.jpg`

**Recommended:**
- Resolution: **1200×900px** or larger
- Aspect ratio: 4:3 landscape
- Show your spa's interior, lobby, or signature space

---

## 🎨 Tips for Best Results

### Image Quality
- Use **JPG for photos** (smaller file size)
- Use **PNG for logos/graphics** (preserves transparency)
- For WebP support: save as `.webp` — even smaller files with same quality

### Compression (Important for Speed!)
Free tools to compress images without visible quality loss:
- [TinyJPG.com](https://tinyjpg.com) — JPG/PNG compression
- [Squoosh.app](https://squoosh.app) — Google's image optimizer
- [Convertio.co](https://convertio.co) — Convert to WebP

### Naming Conventions
- Use **lowercase**, **hyphens**, no spaces: `hero-massage.jpg` ✅
- Not: `Hero Massage.JPG` ❌ or `heroMassage.jpg` ❌

### File Sizes (Targets)
| Type | Target Size | Max Size |
|------|-------------|----------|
| Hero background | 300-500KB | 800KB |
| Category banners | 150-250KB | 400KB |
| Interior/about | 200-350KB | 500KB |
| Logo (SVG) | <10KB | 50KB |
| Logo (PNG) | <100KB | 200KB |

---

## 🔧 Changing Image Paths in Code

If you want to use **different filenames** than the defaults:

1. Open the relevant component file
2. Find the image `src` path
3. Update it to your new filename

**Example:**
```tsx
// In src/components/Hero.tsx
// Change:
<img src="/images/hero-massage.jpg" ... />
// To:
<img src="/images/my-custom-hero.jpg" ... />
```

---

## 📱 Need Help?

If your images look blurry, stretched, or wrong aspect ratio, make sure:
- ✅ You're using the recommended resolution
- ✅ You're using the recommended aspect ratio
- ✅ Your file is in the correct folder (`public/images/`)
- ✅ The filename matches exactly (case-sensitive!)
