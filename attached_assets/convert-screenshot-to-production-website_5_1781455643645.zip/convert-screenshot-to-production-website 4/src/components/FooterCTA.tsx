import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  QuoteIcon,
  CheckIcon,
  ArrowRightIcon,
  InstagramIcon,
  FacebookIcon,
  WhatsappIcon,
  StarIcon,
} from "./Icons";
import { Reveal, T, ease } from "./Motion";

const testimonials = [
  {
    text: "An oasis of calm in the heart of the city. The therapists are exceptional and the ambience is pure luxury.",
    name: "AMAKA O.",
    location: "Lagos, Nigeria",
    initial: "A",
  },
  {
    text: "The Royal Palms Ritual was transformative. I left feeling lighter, brighter, and completely renewed.",
    name: "TOLA B.",
    location: "Lekki, Lagos",
    initial: "T",
  },
  {
    text: "Booked the Couples Retreat for our anniversary — flawless service, divine atmosphere. We'll be back.",
    name: "CHIDI & EBI",
    location: "Victoria Island",
    initial: "C",
  },
  {
    text: "24-hour service was a lifesaver after a red-eye flight. Booked at 2am, treated like royalty.",
    name: "FUNKE A.",
    location: "Ikoyi, Lagos",
    initial: "F",
  },
];

export default function FooterCTA() {
  const [idx, setIdx] = useState(0);

  useEffect(() => {
    const id = setInterval(() => setIdx((i) => (i + 1) % testimonials.length), 6000);
    return () => clearInterval(id);
  }, []);

  const t = testimonials[idx];

  return (
    <section className="py-16 md:py-20 lg:py-24 border-t border-[var(--border-subtle)] bg-gradient-to-b from-[var(--bg-elevated)] to-[var(--bg-base)]">
      <div className="max-w-[1400px] mx-auto px-4 sm:px-6 lg:px-10">
        <Reveal>
          <div className="grid grid-cols-1 lg:grid-cols-2 border border-[var(--border-subtle)] rounded-xl overflow-hidden bg-[var(--bg-card)]">
            {/* Guest Love (carousel) */}
            <div className="p-6 sm:p-8 lg:p-10 border-b lg:border-b-0 lg:border-r border-[var(--border-subtle)] relative min-h-[340px] flex flex-col">
              <div className="flex items-center justify-between mb-4">
                <div className="text-[#d6a24b] text-[10px] tracking-[0.25em] uppercase font-semibold">
                  Guest Love
                </div>
                <div className="flex items-center gap-0.5 text-[#d6a24b]">
                  {Array.from({ length: 5 }).map((_, i) => (
                    <StarIcon key={i} size={12} />
                  ))}
                </div>
              </div>
              <div className="text-[#d6a24b]/50 mb-2">
                <QuoteIcon size={36} />
              </div>

              <div className="relative flex-1 min-h-[180px]">
                <AnimatePresence mode="wait">
                  <motion.div
                    key={idx}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -10 }}
                    transition={T.base}
                    className="absolute inset-0"
                  >
                    <p className="text-[var(--text-primary)] font-serif text-lg sm:text-xl lg:text-2xl leading-snug italic mb-6">
                      {t.text}
                    </p>
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-full bg-gradient-to-br from-[#d6a24b] to-[#93571f] flex items-center justify-center font-display text-black font-bold shrink-0">
                        {t.initial}
                      </div>
                      <div className="min-w-0">
                        <div className="text-[var(--text-primary)] text-sm font-semibold truncate">{t.name}</div>
                        <div className="text-[var(--text-muted)] text-xs truncate">{t.location}</div>
                      </div>
                    </div>
                  </motion.div>
                </AnimatePresence>
              </div>

              <div className="mt-auto pt-6 flex gap-2">
                {testimonials.map((_, i) => (
                  <button
                    key={i}
                    onClick={() => setIdx(i)}
                    className="p-1"
                    aria-label={`Show testimonial ${i + 1}`}
                  >
                    <motion.span
                      className="block h-1 rounded-full"
                      animate={{
                        width: i === idx ? 24 : 8,
                        backgroundColor: i === idx ? "#d6a24b" : "rgba(128,128,128,0.3)",
                      }}
                      transition={{ duration: 0.35, ease: ease.out }}
                    />
                  </button>
                ))}
              </div>
            </div>

            {/* Book CTA + Newsletter panel */}
            <div className="p-6 sm:p-8 lg:p-10 relative overflow-hidden flex flex-col">
              <div className="absolute -right-16 -top-16 text-[#d6a24b] opacity-[0.12] pointer-events-none">
                <svg width="260" height="260" viewBox="0 0 200 200" fill="currentColor">
                  <path d="M100 0 L120 80 L200 100 L120 120 L100 200 L80 120 L0 100 L80 80 Z" />
                </svg>
              </div>

              <div className="relative flex-1">
                <div className="text-[#d6a24b] text-[10px] tracking-[0.25em] uppercase font-semibold mb-4">
                  Ready to unwind?
                </div>
                <h3 className="font-display text-xl sm:text-2xl lg:text-3xl text-[var(--text-primary)] leading-tight mb-4">
                  Reserve your sanctuary
                  <br />
                  <span className="text-[#d6a24b] italic">in moments</span>
                </h3>
                <p className="text-[var(--text-secondary)] text-sm leading-relaxed max-w-md mb-6">
                  Book online 24/7. Instant confirmation. Cancel or reschedule up to 12 hours before with no charge.
                </p>

                <motion.a
                  href="#services"
                  whileHover={{ y: -2 }}
                  whileTap={{ scale: 0.97 }}
                  transition={T.fast}
                  className="btn-gold inline-flex items-center gap-2 bg-[#c88e2e] hover:bg-[#d6a24b] text-black text-xs font-semibold tracking-wider uppercase px-6 py-3.5 rounded-full transition-colors duration-300 group"
                >
                  Book Your Escape
                  <span className="inline-flex items-center justify-center w-6 h-6 rounded-full bg-black/20 group-hover:bg-black/30 transition-colors duration-300">
                    <ArrowRightIcon size={13} />
                  </span>
                </motion.a>
              </div>

              {/* Divider + newsletter */}
              <div className="relative mt-8 pt-6 border-t border-[var(--border-base)]">
                <div className="text-[#d6a24b] text-[10px] tracking-[0.25em] uppercase font-semibold mb-3">
                  Stay In Harmony
                </div>
                <p className="text-[var(--text-secondary)] text-xs mb-3">
                  Wellness tips, exclusive offers, and first access to new rituals.
                </p>
                <NewsletterForm />
                <div className="mt-5 flex items-center gap-3">
                  {[InstagramIcon, FacebookIcon, WhatsappIcon].map((Icon, i) => (
                    <motion.a
                      key={i}
                      href="#"
                      whileHover={{ y: -2, scale: 1.05 }}
                      whileTap={{ scale: 0.95 }}
                      transition={T.fast}
                      className="w-10 h-10 rounded-full border border-[var(--border-base)] hover:border-[#d6a24b] hover:text-[#d6a24b] flex items-center justify-center text-[var(--text-secondary)] transition-colors duration-300"
                    >
                      <Icon size={18} />
                    </motion.a>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </Reveal>
      </div>
    </section>
  );
}

function NewsletterForm() {
  const [email, setEmail] = useState("");
  const [submitted, setSubmitted] = useState(false);

  return (
    <form
      className="relative"
      onSubmit={(e) => {
        e.preventDefault();
        if (!email) return;
        setSubmitted(true);
        setTimeout(() => {
          setSubmitted(false);
          setEmail("");
        }, 2400);
      }}
    >
      <div className="flex items-center border-b border-[var(--border-strong)] focus-within:border-[#d6a24b] transition-colors duration-300 pb-1">
        <input
          type="email"
          required
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          placeholder="Your email address"
          className="flex-1 bg-transparent outline-none text-[var(--text-primary)] placeholder-[var(--text-faint)] text-sm py-2"
        />
        <motion.button
          whileHover={{ scale: 1.08 }}
          whileTap={{ scale: 0.92 }}
          transition={T.fast}
          className="w-9 h-9 rounded-full bg-[#c88e2e] hover:bg-[#d6a24b] text-black flex items-center justify-center transition-colors duration-300 shrink-0"
          aria-label="Subscribe"
        >
          <ArrowRightIcon size={14} />
        </motion.button>
      </div>
      <AnimatePresence>
        {submitted && (
          <motion.div
            initial={{ opacity: 0, y: -4 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -4 }}
            transition={T.fast}
            className="absolute -bottom-6 left-0 text-[#d6a24b] text-xs flex items-center gap-1.5"
          >
            <CheckIcon size={12} />
            Thank you — check your inbox.
          </motion.div>
        )}
      </AnimatePresence>
    </form>
  );
}
