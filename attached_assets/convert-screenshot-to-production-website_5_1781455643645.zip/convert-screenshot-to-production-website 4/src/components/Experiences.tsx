import { motion } from "framer-motion";
import { ArrowRightIcon } from "./Icons";
import { Reveal, StaggerGroup, StaggerItem, T } from "./Motion";

const experiences = [
  {
    badge: null,
    title: "THE HARMONY",
    titleLine: "RETREAT",
    duration: "120 MIN",
    price: "₦120,000",
    desc: "The ultimate mind & body escape.",
    img: "/images/retreat.jpg",
  },
  {
    badge: "MOST LOVED",
    title: "COUPLES",
    titleLine: "RETREAT",
    duration: "120 MIN",
    price: "₦200,000",
    desc: "Shared moments. Lasting connection.",
    img: "/images/couples.jpg",
  },
  {
    badge: null,
    title: "ROYAL PALMS",
    titleLine: "RITUAL",
    duration: "150 MIN",
    price: "₦150,000",
    desc: "Indulgence fit for royalty.",
    img: "/images/ritual.jpg",
  },
];

export default function Experiences() {
  return (
    <section
      id="experiences"
      className="py-16 md:py-20 lg:py-28 relative bg-gradient-to-b from-[var(--bg-base)] to-[var(--bg-elevated)]"
    >
      <div className="max-w-[1400px] mx-auto px-4 sm:px-6 lg:px-10">
        <div className="grid lg:grid-cols-[1fr_1.2fr] gap-8 lg:gap-12 items-start">
          {/* Left copy */}
          <Reveal className="lg:sticky lg:top-32">
            <h2 className="font-display text-2xl sm:text-3xl lg:text-4xl xl:text-5xl leading-[1.1] lg:leading-[1.05] text-[var(--text-primary)] mb-5">
              Experience
              <br />
              <span className="text-[#d6a24b] italic">Harmony</span>
              <br />
              your way
            </h2>
            <p className="text-[var(--text-secondary)] text-sm leading-relaxed max-w-md mb-6">
              Choose from our curated experiences designed for total mind, body & soul renewal.
            </p>
            <motion.a
              href="#services"
              whileHover={{ y: -2 }}
              whileTap={{ scale: 0.97 }}
              transition={T.fast}
              className="btn-gold inline-flex items-center gap-2 bg-[#c88e2e] hover:bg-[#d6a24b] text-black text-xs font-semibold tracking-wider uppercase px-6 py-3.5 rounded-full transition-colors duration-300 group"
            >
              Book An Experience
              <span className="inline-flex items-center justify-center w-5 h-5 rounded-full bg-black/20 group-hover:bg-black/30 transition-colors duration-300">
                <ArrowRightIcon size={12} />
              </span>
            </motion.a>
          </Reveal>

          {/* Cards */}
          <StaggerGroup className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4" delay={0.1}>
            {experiences.map((e) => (
              <StaggerItem key={e.title}>
                <ExperienceCard exp={e} />
              </StaggerItem>
            ))}
          </StaggerGroup>
        </div>
      </div>
    </section>
  );
}

function ExperienceCard({ exp }: { exp: typeof experiences[number] }) {
  return (
    <motion.a
      href="#services"
      whileHover={{ y: -4 }}
      whileTap={{ scale: 0.98 }}
      transition={T.fast}
      className="group block relative aspect-[3/4] rounded-xl overflow-hidden border border-[var(--border-subtle)] bg-black cursor-pointer"
    >
      <div className="absolute inset-0 overflow-hidden">
        <img
          src={exp.img}
          alt={exp.title}
          loading="lazy"
          className="w-full h-full object-cover transition-transform duration-700 ease-out group-hover:scale-105"
        />
      </div>
      <div className="absolute inset-0 bg-gradient-to-t from-black via-black/40 to-black/20 transition-opacity duration-500 group-hover:opacity-90" />

      {exp.badge && (
        <span className="absolute top-3 left-3 bg-[#d6a24b] text-black text-[9px] font-bold tracking-[0.15em] uppercase px-3 py-1 rounded-full shadow-lg shadow-[#d6a24b]/30 z-10">
          {exp.badge}
        </span>
      )}
      <div className="absolute inset-x-0 bottom-0 p-4 flex flex-col items-start z-10">
        <div className="font-display text-white text-lg sm:text-xl leading-tight mb-2">
          {exp.title}
          <br />
          {exp.titleLine}
        </div>
        <div className="text-[11px] tracking-wider text-[#d6a24b] font-semibold mb-2">
          {exp.duration} · {exp.price}
        </div>
        <p className="text-white/70 text-xs leading-snug mb-3">{exp.desc}</p>
        <div className="inline-flex items-center gap-2 text-white text-[10px] tracking-[0.2em] uppercase border-b border-white/30 pb-0.5 transition-all duration-300 group-hover:border-[#d6a24b] group-hover:text-[#d6a24b] group-hover:translate-x-1">
          View Details
          <ArrowRightIcon size={12} />
        </div>
      </div>
    </motion.a>
  );
}
