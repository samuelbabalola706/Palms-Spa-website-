import LogoSVG from "./LogoSVG";

type LogoProps = {
  size?: number;
  className?: string;
};

/**
 * The Harmony Palms logo.
 *
 * ⚡ INSTANT LOAD: The SVG is inlined directly into the component,
 * so the logo appears on the very first paint — no HTTP request,
 * no file fetch, no delay. It's part of the initial HTML bundle.
 */
export default function Logo({ size = 40, className }: LogoProps) {
  return (
    <LogoSVG
      width={size}
      height={size}
      className={className}
      style={{ width: size, height: size, display: "block" }}
      aria-hidden="false"
    />
  );
}
